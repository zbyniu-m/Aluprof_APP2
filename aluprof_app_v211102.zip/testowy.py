import time

var = '07:10'

var = time.strptime(var, '%H:%M')
print(var.tm_hour)
print(var.tm_min)
